import { useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { useLocation } from "wouter";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Label } from "@/components/ui/label";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { BookOpen, Globe, Target, Clock, Users, ArrowRight, ArrowLeft, CheckCircle } from "lucide-react";
import { LANGUAGES } from "@shared/schema";

interface OnboardingData {
  isNewLearner: boolean | null;
  targetLanguage: string | null;
  skillLevel: string | null;
  dailyTimeMinutes: number | null;
  referralSource: string | null;
}

const steps = [
  { id: 1, title: "Experience", icon: Users },
  { id: 2, title: "Language", icon: Globe },
  { id: 3, title: "Skill Level", icon: Target },
  { id: 4, title: "Daily Goal", icon: Clock },
  { id: 5, title: "How You Found Us", icon: BookOpen },
];

const skillLevels = [
  { value: "beginner", label: "Beginner", description: "I'm just starting to learn" },
  { value: "intermediate", label: "Intermediate", description: "I know some basics" },
  { value: "expert", label: "Expert", description: "I can hold conversations" },
  { value: "master", label: "Master", description: "I want to perfect my skills" },
];

const timeOptions = [
  { value: 5, label: "5 minutes" },
  { value: 10, label: "10 minutes" },
  { value: 15, label: "15 minutes" },
  { value: 20, label: "20 minutes" },
  { value: 25, label: "25 minutes" },
  { value: 30, label: "30 minutes" },
];

const referralOptions = [
  { value: "youtuber", label: "YouTuber" },
  { value: "twitter", label: "Twitter/X" },
  { value: "instagram", label: "Instagram" },
  { value: "google", label: "Google Search" },
  { value: "other", label: "Other" },
];

export default function OnboardingPage() {
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [currentStep, setCurrentStep] = useState(1);
  const [data, setData] = useState<OnboardingData>({
    isNewLearner: null,
    targetLanguage: null,
    skillLevel: null,
    dailyTimeMinutes: null,
    referralSource: null,
  });

  const saveMutation = useMutation({
    mutationFn: async (onboardingData: OnboardingData) => {
      const res = await apiRequest("POST", "/api/onboarding", {
        isNewLearner: onboardingData.isNewLearner,
        targetLanguage: onboardingData.targetLanguage,
        skillLevel: onboardingData.skillLevel,
        dailyTimeMinutes: onboardingData.dailyTimeMinutes,
        referralSource: onboardingData.referralSource,
      });
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/user"] });
      toast({ title: "Welcome to LinguaQuest!", description: "Your learning journey begins now." });
      setLocation("/dashboard");
    },
    onError: () => {
      toast({ title: "Error", description: "Failed to save preferences", variant: "destructive" });
    },
  });

  const canProceed = () => {
    switch (currentStep) {
      case 1: return data.isNewLearner !== null;
      case 2: return data.targetLanguage !== null;
      case 3: return data.skillLevel !== null;
      case 4: return data.dailyTimeMinutes !== null;
      case 5: return data.referralSource !== null;
      default: return false;
    }
  };

  const handleNext = () => {
    if (currentStep < 5) {
      setCurrentStep(currentStep + 1);
    } else {
      saveMutation.mutate(data);
    }
  };

  const handleBack = () => {
    if (currentStep > 1) {
      setCurrentStep(currentStep - 1);
    }
  };

  const progress = (currentStep / 5) * 100;

  return (
    <div className="min-h-screen flex items-center justify-center p-4 bg-gradient-to-b from-primary/5 to-background">
      <Card className="w-full max-w-lg">
        <CardHeader className="text-center">
          <div className="flex items-center justify-center gap-2 mb-4">
            <BookOpen className="h-8 w-8 text-primary" />
            <CardTitle className="text-2xl">LinguaQuest Setup</CardTitle>
          </div>
          <Progress value={progress} className="h-2" />
          <div className="flex justify-center gap-2 mt-4">
            {steps.map((step) => (
              <div
                key={step.id}
                className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-medium ${
                  step.id === currentStep
                    ? "bg-primary text-white"
                    : step.id < currentStep
                    ? "bg-primary/20 text-primary"
                    : "bg-muted text-muted-foreground"
                }`}
              >
                {step.id < currentStep ? <CheckCircle className="h-4 w-4" /> : step.id}
              </div>
            ))}
          </div>
        </CardHeader>
        <CardContent className="space-y-6">
          {currentStep === 1 && (
            <div className="space-y-4">
              <h3 className="text-lg font-semibold text-center">Are you new to language learning?</h3>
              <RadioGroup
                value={data.isNewLearner?.toString()}
                onValueChange={(val) => setData({ ...data, isNewLearner: val === "true" })}
              >
                <div
                  className={`flex items-center space-x-3 p-4 border rounded-md hover-elevate cursor-pointer ${
                    data.isNewLearner === true ? "border-primary bg-primary/5" : ""
                  }`}
                  data-testid="option-new-yes"
                >
                  <RadioGroupItem value="true" id="new-yes" />
                  <Label htmlFor="new-yes" className="flex-1 cursor-pointer">
                    <span className="font-medium">Yes, I'm new</span>
                    <p className="text-sm text-muted-foreground">This is my first time learning a new language</p>
                  </Label>
                </div>
                <div
                  className={`flex items-center space-x-3 p-4 border rounded-md hover-elevate cursor-pointer ${
                    data.isNewLearner === false ? "border-primary bg-primary/5" : ""
                  }`}
                  data-testid="option-new-no"
                >
                  <RadioGroupItem value="false" id="new-no" />
                  <Label htmlFor="new-no" className="flex-1 cursor-pointer">
                    <span className="font-medium">No, I have experience</span>
                    <p className="text-sm text-muted-foreground">I've learned languages before</p>
                  </Label>
                </div>
              </RadioGroup>
            </div>
          )}

          {currentStep === 2 && (
            <div className="space-y-4">
              <h3 className="text-lg font-semibold text-center">What language do you want to learn?</h3>
              <RadioGroup
                value={data.targetLanguage || ""}
                onValueChange={(val) => setData({ ...data, targetLanguage: val })}
                className="grid grid-cols-2 gap-3"
              >
                {LANGUAGES.map((lang) => (
                  <div
                    key={lang.code}
                    className={`flex items-center space-x-3 p-4 border rounded-md hover-elevate cursor-pointer ${
                      data.targetLanguage === lang.code ? "border-primary bg-primary/5" : ""
                    }`}
                    data-testid={`option-lang-${lang.code}`}
                  >
                    <RadioGroupItem value={lang.code} id={`lang-${lang.code}`} />
                    <Label htmlFor={`lang-${lang.code}`} className="flex-1 cursor-pointer font-medium">
                      {lang.name}
                    </Label>
                  </div>
                ))}
              </RadioGroup>
            </div>
          )}

          {currentStep === 3 && (
            <div className="space-y-4">
              <h3 className="text-lg font-semibold text-center">How advanced are you in this language?</h3>
              <RadioGroup
                value={data.skillLevel || ""}
                onValueChange={(val) => setData({ ...data, skillLevel: val })}
              >
                {skillLevels.map((level) => (
                  <div
                    key={level.value}
                    className={`flex items-center space-x-3 p-4 border rounded-md hover-elevate cursor-pointer ${
                      data.skillLevel === level.value ? "border-primary bg-primary/5" : ""
                    }`}
                    data-testid={`option-skill-${level.value}`}
                  >
                    <RadioGroupItem value={level.value} id={`skill-${level.value}`} />
                    <Label htmlFor={`skill-${level.value}`} className="flex-1 cursor-pointer">
                      <span className="font-medium">{level.label}</span>
                      <p className="text-sm text-muted-foreground">{level.description}</p>
                    </Label>
                  </div>
                ))}
              </RadioGroup>
            </div>
          )}

          {currentStep === 4 && (
            <div className="space-y-4">
              <h3 className="text-lg font-semibold text-center">How much time will you give daily?</h3>
              <RadioGroup
                value={data.dailyTimeMinutes?.toString() || ""}
                onValueChange={(val) => setData({ ...data, dailyTimeMinutes: parseInt(val) })}
                className="grid grid-cols-2 gap-3"
              >
                {timeOptions.map((time) => (
                  <div
                    key={time.value}
                    className={`flex items-center space-x-3 p-4 border rounded-md hover-elevate cursor-pointer ${
                      data.dailyTimeMinutes === time.value ? "border-primary bg-primary/5" : ""
                    }`}
                    data-testid={`option-time-${time.value}`}
                  >
                    <RadioGroupItem value={time.value.toString()} id={`time-${time.value}`} />
                    <Label htmlFor={`time-${time.value}`} className="flex-1 cursor-pointer font-medium">
                      {time.label}
                    </Label>
                  </div>
                ))}
              </RadioGroup>
            </div>
          )}

          {currentStep === 5 && (
            <div className="space-y-4">
              <h3 className="text-lg font-semibold text-center">How did you find LinguaQuest?</h3>
              <RadioGroup
                value={data.referralSource || ""}
                onValueChange={(val) => setData({ ...data, referralSource: val })}
              >
                {referralOptions.map((option) => (
                  <div
                    key={option.value}
                    className={`flex items-center space-x-3 p-4 border rounded-md hover-elevate cursor-pointer ${
                      data.referralSource === option.value ? "border-primary bg-primary/5" : ""
                    }`}
                    data-testid={`option-referral-${option.value}`}
                  >
                    <RadioGroupItem value={option.value} id={`ref-${option.value}`} />
                    <Label htmlFor={`ref-${option.value}`} className="flex-1 cursor-pointer font-medium">
                      {option.label}
                    </Label>
                  </div>
                ))}
              </RadioGroup>
            </div>
          )}

          <div className="flex justify-between pt-4">
            <Button
              variant="ghost"
              onClick={handleBack}
              disabled={currentStep === 1}
              data-testid="button-back"
            >
              <ArrowLeft className="h-4 w-4 mr-2" />
              Back
            </Button>
            <Button
              onClick={handleNext}
              disabled={!canProceed() || saveMutation.isPending}
              data-testid="button-next"
            >
              {saveMutation.isPending
                ? "Saving..."
                : currentStep === 5
                ? "Get Started"
                : "Next"}
              {currentStep < 5 && <ArrowRight className="h-4 w-4 ml-2" />}
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
