import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Skeleton } from "@/components/ui/skeleton";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { Target, Calendar, Gift, CheckCircle } from "lucide-react";
import type { Quest } from "@shared/schema";

type QuestWithProgress = Quest & { progress?: number; completed?: boolean; claimed?: boolean };

export default function QuestsPage() {
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: quests, isLoading } = useQuery<QuestWithProgress[]>({
    queryKey: ["/api/quests"],
  });

  const claimMutation = useMutation({
    mutationFn: async (questId: number) => {
      const res = await apiRequest("POST", `/api/quests/${questId}/claim`, {});
      return res.json();
    },
    onSuccess: (_, questId) => {
      queryClient.invalidateQueries({ queryKey: ["/api/quests"] });
      queryClient.invalidateQueries({ queryKey: ["/api/user"] });
      toast({ title: "Quest claimed!", description: "XP has been added to your account." });
    },
  });

  const dailyQuests = quests?.filter((q) => q.type === "Daily") || [];
  const monthlyQuests = quests?.filter((q) => q.type === "Monthly") || [];

  const QuestCard = ({ quest }: { quest: QuestWithProgress }) => {
    const progressPercent = quest.targetCount > 0 ? ((quest.progress || 0) / quest.targetCount) * 100 : 0;
    const isComplete = progressPercent >= 100;

    return (
      <Card className={quest.claimed ? "opacity-60" : ""} data-testid={`card-quest-${quest.id}`}>
        <CardContent className="p-4">
          <div className="flex items-start justify-between gap-4">
            <div className="flex-1 space-y-2">
              <div className="flex items-center gap-2">
                <Target className="h-5 w-5 text-primary" />
                <span className="font-medium">{quest.description}</span>
              </div>
              <div className="flex items-center gap-2">
                <Progress value={Math.min(progressPercent, 100)} className="h-2 flex-1" />
                <span className="text-sm text-muted-foreground">
                  {quest.progress || 0}/{quest.targetCount}
                </span>
              </div>
            </div>
            <div className="flex flex-col items-end gap-2">
              <Badge variant="secondary" className="flex items-center gap-1">
                <Gift className="h-3 w-3" />
                +{quest.rewardXp} XP
              </Badge>
              {quest.claimed ? (
                <Badge variant="outline" className="flex items-center gap-1">
                  <CheckCircle className="h-3 w-3" />
                  Claimed
                </Badge>
              ) : isComplete ? (
                <Button
                  size="sm"
                  onClick={() => claimMutation.mutate(quest.id)}
                  disabled={claimMutation.isPending}
                  data-testid={`button-claim-${quest.id}`}
                >
                  Claim
                </Button>
              ) : null}
            </div>
          </div>
        </CardContent>
      </Card>
    );
  };

  return (
    <div className="p-6 max-w-4xl mx-auto space-y-8">
      <div>
        <h1 className="text-3xl font-bold flex items-center gap-2">
          <Target className="h-8 w-8 text-primary" />
          Quests
        </h1>
        <p className="text-muted-foreground mt-1">Complete challenges to earn XP and rewards</p>
      </div>

      <Tabs defaultValue="daily" className="w-full">
        <TabsList className="grid w-full grid-cols-2 max-w-sm">
          <TabsTrigger value="daily" data-testid="tab-daily-quests">
            <Target className="h-4 w-4 mr-2" />
            Daily ({dailyQuests.length})
          </TabsTrigger>
          <TabsTrigger value="monthly" data-testid="tab-monthly-quests">
            <Calendar className="h-4 w-4 mr-2" />
            Monthly ({monthlyQuests.length})
          </TabsTrigger>
        </TabsList>

        <TabsContent value="daily" className="mt-6 space-y-4">
          {isLoading ? (
            <>
              <Skeleton className="h-24" />
              <Skeleton className="h-24" />
              <Skeleton className="h-24" />
            </>
          ) : dailyQuests.length === 0 ? (
            <Card className="p-8 text-center">
              <p className="text-muted-foreground">No daily quests available.</p>
            </Card>
          ) : (
            dailyQuests.map((quest) => <QuestCard key={quest.id} quest={quest} />)
          )}
        </TabsContent>

        <TabsContent value="monthly" className="mt-6 space-y-4">
          {isLoading ? (
            <>
              <Skeleton className="h-24" />
              <Skeleton className="h-24" />
            </>
          ) : monthlyQuests.length === 0 ? (
            <Card className="p-8 text-center">
              <p className="text-muted-foreground">No monthly quests available.</p>
            </Card>
          ) : (
            monthlyQuests.map((quest) => <QuestCard key={quest.id} quest={quest} />)
          )}
        </TabsContent>
      </Tabs>
    </div>
  );
}
