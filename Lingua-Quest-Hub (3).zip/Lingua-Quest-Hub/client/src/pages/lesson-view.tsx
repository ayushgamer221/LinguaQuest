import { useState, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useParams, Link, useLocation, useSearch } from "wouter";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Progress } from "@/components/ui/progress";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Label } from "@/components/ui/label";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { ArrowLeft, CheckCircle, XCircle, Volume2, BookOpen, Eye } from "lucide-react";
import { AITutor } from "@/components/ai-tutor";
import type { Lesson, LessonProgress } from "@shared/schema";

interface QuizQuestion {
  question: string;
  options: string[];
  correctIndex: number;
}

export default function LessonViewPage() {
  const { id } = useParams<{ id: string }>();
  const [, setLocation] = useLocation();
  const searchString = useSearch();
  const isReviewMode = searchString.includes("review=true");
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
  const [selectedAnswer, setSelectedAnswer] = useState<number | null>(null);
  const [showResult, setShowResult] = useState(false);
  const [correctAnswers, setCorrectAnswers] = useState(0);
  const [quizCompleted, setQuizCompleted] = useState(false);
  const [userAnswers, setUserAnswers] = useState<number[]>([]);

  const { data: lesson, isLoading } = useQuery<Lesson>({
    queryKey: ["/api/lessons", id],
    queryFn: async () => {
      const res = await fetch(`/api/lessons/${id}`);
      if (!res.ok) throw new Error("Failed to fetch lesson");
      return res.json();
    },
  });

  const { data: lessonProgress } = useQuery<LessonProgress>({
    queryKey: ["/api/lessons", id, "progress"],
    queryFn: async () => {
      const res = await fetch(`/api/lessons/${id}/progress`);
      if (!res.ok) return null;
      return res.json();
    },
    enabled: isReviewMode,
  });

  const completeMutation = useMutation({
    mutationFn: async ({ score, answers }: { score: number; answers: number[] }) => {
      const res = await apiRequest("POST", `/api/lessons/${id}/complete`, { score, userAnswers: answers });
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/user"] });
      queryClient.invalidateQueries({ queryKey: ["/api/progress"] });
      toast({ title: "Lesson completed!", description: "You earned XP for completing this lesson." });
    },
  });

  const quizConfig = (lesson?.quizConfig as QuizQuestion[]) || [];
  const currentQuestion = quizConfig[currentQuestionIndex];

  const handleAnswerSubmit = () => {
    if (selectedAnswer === null || !currentQuestion) return;

    setShowResult(true);
    setUserAnswers((prev) => [...prev, selectedAnswer]);
    if (selectedAnswer === currentQuestion.correctIndex) {
      setCorrectAnswers((prev) => prev + 1);
    }
  };

  const handleNextQuestion = () => {
    if (!currentQuestion) return;

    if (currentQuestionIndex + 1 < quizConfig.length) {
      setCurrentQuestionIndex((prev) => prev + 1);
      setSelectedAnswer(null);
      setShowResult(false);
    } else {
      const finalCorrect = selectedAnswer === currentQuestion.correctIndex ? correctAnswers + 1 : correctAnswers;
      const score = quizConfig.length > 0 ? Math.round((finalCorrect / quizConfig.length) * 100) : 100;
      setQuizCompleted(true);
      completeMutation.mutate({ score, answers: [...userAnswers, selectedAnswer!] });
    }
  };

  const handleCompleteWithoutQuiz = () => {
    completeMutation.mutate({ score: 100, answers: [] });
    setQuizCompleted(true);
  };

  const savedAnswers = (lessonProgress?.userAnswers as number[]) || [];

  if (isLoading) {
    return (
      <div className="p-6 max-w-4xl mx-auto space-y-6">
        <Skeleton className="h-10 w-48" />
        <Skeleton className="h-96" />
      </div>
    );
  }

  if (!lesson) {
    return (
      <div className="p-6 max-w-4xl mx-auto">
        <Card className="p-8 text-center">
          <p className="text-muted-foreground">Lesson not found</p>
          <Link href="/lessons">
            <Button className="mt-4">Back to Lessons</Button>
          </Link>
        </Card>
      </div>
    );
  }

  return (
    <div className="p-6 max-w-4xl mx-auto space-y-6">
      <div className="flex items-center gap-4">
        <Link href="/lessons">
          <Button variant="ghost" size="icon" data-testid="button-back">
            <ArrowLeft className="h-5 w-5" />
          </Button>
        </Link>
        <div>
          <h1 className="text-2xl font-bold" data-testid="text-lesson-title">{lesson.title}</h1>
          <Badge variant="outline">{lesson.difficulty}</Badge>
        </div>
      </div>

      <Card data-testid="card-lesson-content">
        <CardHeader className="gap-2">
          <div className="flex items-center justify-between gap-2">
            <CardTitle className="flex items-center gap-2">
              <BookOpen className="h-5 w-5" />
              Lesson Content
            </CardTitle>
            <Button variant="ghost" size="icon" data-testid="button-audio">
              <Volume2 className="h-5 w-5" />
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          <div className="prose prose-sm max-w-none dark:prose-invert">
            {lesson.content.split("\n").map((line, i) => {
              if (line.startsWith("# ")) {
                return <h2 key={i} className="text-xl font-bold mt-4 mb-2">{line.replace("# ", "")}</h2>;
              }
              if (line.startsWith("- **")) {
                return (
                  <p key={i} className="my-1">
                    <strong>{line.match(/\*\*(.*?)\*\*/)?.[1]}</strong>
                    {line.replace(/- \*\*.*?\*\*/, "")}
                  </p>
                );
              }
              return <p key={i} className="my-2">{line}</p>;
            })}
          </div>
        </CardContent>
      </Card>

      <AITutor lessonTitle={lesson.title} lessonContent={lesson.content} />

      {isReviewMode && quizConfig.length > 0 ? (
        <Card data-testid="card-quiz-review">
          <CardHeader className="gap-2">
            <div className="flex items-center justify-between gap-2">
              <CardTitle className="flex items-center gap-2">
                <Eye className="h-5 w-5" />
                Quiz Review
              </CardTitle>
              <Badge variant="secondary">
                Score: {lessonProgress?.score ?? 0}%
              </Badge>
            </div>
          </CardHeader>
          <CardContent className="space-y-6">
            {quizConfig.map((question, qIndex) => {
              const userAnswer = savedAnswers[qIndex];
              const isCorrect = userAnswer === question.correctIndex;
              return (
                <div key={qIndex} className="space-y-3 pb-4 border-b last:border-b-0">
                  <div className="flex items-start gap-2">
                    <span className="font-medium text-muted-foreground">{qIndex + 1}.</span>
                    <p className="font-medium">{question.question}</p>
                  </div>
                  <div className="space-y-2 ml-6">
                    {question.options.map((option, oIndex) => (
                      <div
                        key={oIndex}
                        className={`flex items-center gap-3 p-3 border rounded-md ${
                          oIndex === question.correctIndex
                            ? "border-green-500 bg-green-50 dark:bg-green-950"
                            : userAnswer === oIndex
                            ? "border-red-500 bg-red-50 dark:bg-red-950"
                            : ""
                        }`}
                      >
                        <span className="flex-1">{option}</span>
                        {oIndex === question.correctIndex && (
                          <CheckCircle className="h-4 w-4 text-green-500" />
                        )}
                        {userAnswer === oIndex && oIndex !== question.correctIndex && (
                          <XCircle className="h-4 w-4 text-red-500" />
                        )}
                        {userAnswer === oIndex && (
                          <Badge variant="outline" className="text-xs">Your answer</Badge>
                        )}
                      </div>
                    ))}
                  </div>
                </div>
              );
            })}
            <div className="flex justify-end pt-4">
              <Link href="/lessons?tab=completed">
                <Button data-testid="button-back-to-lessons">Back to Lessons</Button>
              </Link>
            </div>
          </CardContent>
        </Card>
      ) : quizConfig.length > 0 && currentQuestion && !quizCompleted ? (
        <Card data-testid="card-quiz">
          <CardHeader className="gap-2">
            <div className="flex items-center justify-between gap-2">
              <CardTitle>Quiz</CardTitle>
              <span className="text-sm text-muted-foreground">
                Question {currentQuestionIndex + 1} of {quizConfig.length}
              </span>
            </div>
            <Progress value={((currentQuestionIndex + 1) / quizConfig.length) * 100} className="h-2" />
          </CardHeader>
          <CardContent className="space-y-6">
            <p className="text-lg font-medium">{currentQuestion.question}</p>

            <RadioGroup
              value={selectedAnswer?.toString()}
              onValueChange={(val) => !showResult && setSelectedAnswer(parseInt(val))}
            >
              {currentQuestion.options.map((option, index) => (
                <div
                  key={index}
                  className={`flex items-center space-x-3 p-4 border rounded-md ${
                    showResult
                      ? index === currentQuestion.correctIndex
                        ? "border-green-500 bg-green-50 dark:bg-green-950"
                        : selectedAnswer === index
                        ? "border-red-500 bg-red-50 dark:bg-red-950"
                        : ""
                      : "hover-elevate cursor-pointer"
                  }`}
                  data-testid={`option-${index}`}
                >
                  <RadioGroupItem value={index.toString()} id={`option-${index}`} disabled={showResult} />
                  <Label htmlFor={`option-${index}`} className="flex-1 cursor-pointer">
                    {option}
                  </Label>
                  {showResult && index === currentQuestion.correctIndex && (
                    <CheckCircle className="h-5 w-5 text-green-500" />
                  )}
                  {showResult && selectedAnswer === index && index !== currentQuestion.correctIndex && (
                    <XCircle className="h-5 w-5 text-red-500" />
                  )}
                </div>
              ))}
            </RadioGroup>

            <div className="flex justify-end gap-4">
              {!showResult ? (
                <Button onClick={handleAnswerSubmit} disabled={selectedAnswer === null} data-testid="button-submit-answer">
                  Submit Answer
                </Button>
              ) : (
                <Button onClick={handleNextQuestion} data-testid="button-next-question">
                  {currentQuestionIndex + 1 < quizConfig.length ? "Next Question" : "Finish Quiz"}
                </Button>
              )}
            </div>
          </CardContent>
        </Card>
      ) : quizCompleted ? (
        <Card className="text-center p-8" data-testid="card-quiz-result">
          <CheckCircle className="h-16 w-16 text-green-500 mx-auto mb-4" />
          <h2 className="text-2xl font-bold mb-2">Lesson Complete!</h2>
          <p className="text-muted-foreground mb-4">
            {quizConfig.length > 0
              ? `You got ${correctAnswers} out of ${quizConfig.length} questions correct.`
              : "Great job completing this lesson!"}
          </p>
          <Link href="/lessons">
            <Button data-testid="button-continue">Continue Learning</Button>
          </Link>
        </Card>
      ) : (
        <Card className="text-center p-8">
          <p className="text-muted-foreground mb-4">This lesson has no quiz.</p>
          <Button onClick={handleCompleteWithoutQuiz} data-testid="button-mark-complete">
            Mark as Complete
          </Button>
        </Card>
      )}
    </div>
  );
}
