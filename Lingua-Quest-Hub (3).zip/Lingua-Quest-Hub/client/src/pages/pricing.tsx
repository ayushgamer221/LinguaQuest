import { useState } from "react";
import { useMutation, useQuery } from "@tanstack/react-query";
import { useAuth } from "@/lib/auth";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Checkbox } from "@/components/ui/checkbox";
import { Label } from "@/components/ui/label";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { Check, Crown, Star, Zap, Rocket, Shield } from "lucide-react";
import { PLANS, type PlanType } from "@shared/schema";
import { Link } from "wouter";

interface StripeProduct {
  id: string;
  name: string;
  description: string;
  metadata: { features?: string };
  prices: Array<{
    id: string;
    unitAmount: number;
    currency: string;
    recurring: { interval: string };
  }>;
}

const planIcons: Record<PlanType, React.ReactNode> = {
  FreePack: <Star className="h-8 w-8" />,
  Rookie: <Zap className="h-8 w-8" />,
  Intermediate: <Shield className="h-8 w-8" />,
  Expert: <Rocket className="h-8 w-8" />,
  Master: <Crown className="h-8 w-8" />,
};

export default function PricingPage() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [termsAccepted, setTermsAccepted] = useState(false);
  const [selectedPlan, setSelectedPlan] = useState<PlanType | null>(null);

  const { data: stripeData } = useQuery<{ products: StripeProduct[] }>({
    queryKey: ["/api/stripe/products"],
  });

  const stripeProducts = stripeData?.products || [];

  const getStripePriceId = (planName: string): string | null => {
    const product = stripeProducts.find(p => p.name === planName);
    return product?.prices?.[0]?.id || null;
  };

  const checkoutMutation = useMutation({
    mutationFn: async ({ plan, priceId }: { plan: string; priceId: string }) => {
      const res = await apiRequest("POST", "/api/subscription/checkout", { plan, priceId });
      return res.json();
    },
    onSuccess: (data) => {
      if (data.url) {
        window.location.href = data.url;
      }
    },
    onError: () => {
      toast({ title: "Error", description: "Failed to start checkout", variant: "destructive" });
    },
  });

  const handleSubscribe = (plan: PlanType) => {
    if (plan === "FreePack") return;

    if (!user) {
      toast({ title: "Login required", description: "Please login to subscribe", variant: "destructive" });
      return;
    }

    if (!termsAccepted) {
      toast({ title: "Terms required", description: "Please accept the terms to continue", variant: "destructive" });
      return;
    }

    const priceId = getStripePriceId(plan);
    if (!priceId) {
      toast({ title: "Error", description: "Plan not available yet", variant: "destructive" });
      return;
    }

    checkoutMutation.mutate({ plan, priceId });
  };

  return (
    <div className="p-6 max-w-7xl mx-auto space-y-8">
      <div className="text-center space-y-4">
        <h1 className="text-4xl font-bold">Choose Your Learning Path</h1>
        <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
          Unlock premium features and accelerate your English learning journey
        </p>
      </div>

      <div className="bg-amber-50 dark:bg-amber-950 border border-amber-200 dark:border-amber-800 rounded-lg p-6 text-center space-y-2">
        <p className="font-bold text-lg">
          ALL SUBSCRIPTIONS ARE RECURRING MONTHLY AND CAN BE CANCELED ANYTIME FROM YOUR PROFILE DASHBOARD. NO HIDDEN FEES.
        </p>
        <p className="font-semibold text-amber-700 dark:text-amber-300">
          3 DAY REFUND POLICY — REQUEST WITHIN 72 HOURS AFTER PURCHASE.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4">
        {(Object.keys(PLANS) as PlanType[]).map((planKey) => {
          const plan = PLANS[planKey];
          const isCurrentPlan = user?.plan === planKey;
          const isFree = planKey === "FreePack";

          return (
            <Card
              key={planKey}
              className={`relative ${planKey === "Expert" ? "border-primary border-2" : ""}`}
              data-testid={`card-plan-${planKey}`}
            >
              {planKey === "Expert" && (
                <Badge className="absolute -top-3 left-1/2 transform -translate-x-1/2">Most Popular</Badge>
              )}
              <CardHeader className="text-center pb-4 gap-2">
                <div className="mx-auto text-primary">{planIcons[planKey]}</div>
                <CardTitle>{planKey}</CardTitle>
                <CardDescription>
                  <span className="text-3xl font-bold">${plan.price}</span>
                  {!isFree && <span className="text-muted-foreground">/month</span>}
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <ul className="space-y-2 text-sm">
                  {plan.features.map((feature, i) => (
                    <li key={i} className="flex items-start gap-2">
                      <Check className="h-4 w-4 text-primary mt-0.5 flex-shrink-0" />
                      <span>{feature}</span>
                    </li>
                  ))}
                </ul>
                {isCurrentPlan ? (
                  <Button variant="outline" disabled className="w-full" data-testid={`button-current-${planKey}`}>
                    Current Plan
                  </Button>
                ) : isFree ? (
                  <Button variant="outline" disabled className="w-full">
                    Free
                  </Button>
                ) : (
                  <Button
                    className="w-full"
                    onClick={() => {
                      setSelectedPlan(planKey);
                      handleSubscribe(planKey);
                    }}
                    disabled={checkoutMutation.isPending}
                    data-testid={`button-subscribe-${planKey}`}
                  >
                    {checkoutMutation.isPending && selectedPlan === planKey ? "Processing..." : "Subscribe"}
                  </Button>
                )}
              </CardContent>
            </Card>
          );
        })}
      </div>

      <Card className="max-w-xl mx-auto">
        <CardContent className="p-6">
          <div className="flex items-start space-x-3">
            <Checkbox
              id="terms"
              checked={termsAccepted}
              onCheckedChange={(checked) => setTermsAccepted(checked === true)}
              data-testid="checkbox-terms"
            />
            <Label htmlFor="terms" className="text-sm leading-relaxed cursor-pointer">
              I understand that subscriptions are billed monthly and can be canceled anytime.
              I agree to the terms of service and acknowledge the 3-day refund policy.
            </Label>
          </div>
        </CardContent>
      </Card>

      {!user && (
        <div className="text-center">
          <p className="text-muted-foreground mb-4">Already have an account?</p>
          <Link href="/auth">
            <Button variant="outline" data-testid="button-login-pricing">Login to Subscribe</Button>
          </Link>
        </div>
      )}
    </div>
  );
}
