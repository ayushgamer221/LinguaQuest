import { useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { useAuth } from "@/lib/auth";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { useToast } from "@/hooks/use-toast";
import { apiRequest } from "@/lib/queryClient";
import { User, CreditCard, LogOut, AlertTriangle, Settings, Shield } from "lucide-react";
import { PLANS } from "@shared/schema";
import { Link } from "wouter";

export default function ProfilePage() {
  const { user, logout } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [showCancelConfirm, setShowCancelConfirm] = useState(false);
  const [showRefundConfirm, setShowRefundConfirm] = useState(false);

  const cancelMutation = useMutation({
    mutationFn: async () => {
      const res = await apiRequest("POST", "/api/subscription/cancel", {});
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/user"] });
      toast({ title: "Subscription canceled", description: "Your access continues until the end of the billing period." });
      setShowCancelConfirm(false);
    },
  });

  const refundMutation = useMutation({
    mutationFn: async () => {
      const res = await apiRequest("POST", "/api/subscription/refund", {});
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/user"] });
      toast({ title: "Refund processed", description: "Your subscription has been refunded." });
      setShowRefundConfirm(false);
    },
    onError: () => {
      toast({ title: "Refund failed", description: "Refunds must be requested within 72 hours.", variant: "destructive" });
    },
  });

  const handleLogout = async () => {
    await logout();
    window.location.href = "/";
  };

  if (!user) {
    return (
      <div className="p-6 max-w-2xl mx-auto">
        <Card className="text-center p-8">
          <p className="text-muted-foreground mb-4">Please login to view your profile</p>
          <Link href="/auth">
            <Button>Login</Button>
          </Link>
        </Card>
      </div>
    );
  }

  const currentPlan = PLANS[user.plan as keyof typeof PLANS] || PLANS.FreePack;
  const isPaid = user.plan !== "FreePack";

  return (
    <div className="p-6 max-w-2xl mx-auto space-y-6">
      <h1 className="text-3xl font-bold flex items-center gap-2">
        <Settings className="h-8 w-8" />
        Profile & Settings
      </h1>

      <Card data-testid="card-profile-info">
        <CardHeader className="gap-2">
          <CardTitle className="flex items-center gap-2">
            <User className="h-5 w-5" />
            Account Information
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div>
              <p className="text-sm text-muted-foreground">Display Name</p>
              <p className="font-medium">{user.displayName || "Not set"}</p>
            </div>
            <div>
              <p className="text-sm text-muted-foreground">Email</p>
              <p className="font-medium">{user.username}</p>
            </div>
            <div>
              <p className="text-sm text-muted-foreground">XP</p>
              <p className="font-medium">{user.xp}</p>
            </div>
            <div>
              <p className="text-sm text-muted-foreground">Streak</p>
              <p className="font-medium">{user.streak} days</p>
            </div>
          </div>
        </CardContent>
      </Card>

      <Card data-testid="card-subscription">
        <CardHeader className="gap-2">
          <CardTitle className="flex items-center gap-2">
            <CreditCard className="h-5 w-5" />
            Subscription
          </CardTitle>
          <CardDescription>Manage your subscription plan</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="font-medium text-lg">{user.plan}</p>
              <p className="text-sm text-muted-foreground">${currentPlan.price}/month</p>
            </div>
            <Badge variant={isPaid ? "default" : "secondary"}>
              {user.subscriptionStatus === "canceled" ? "Canceled" : isPaid ? "Active" : "Free"}
            </Badge>
          </div>

          <Separator />

          <div className="space-y-2">
            <h4 className="font-medium">Plan Features</h4>
            <ul className="text-sm text-muted-foreground space-y-1">
              {currentPlan.features.map((f, i) => (
                <li key={i}>• {f}</li>
              ))}
            </ul>
          </div>

          {isPaid && user.subscriptionStatus !== "canceled" && (
            <div className="space-y-4 pt-4">
              {!showCancelConfirm ? (
                <Button
                  variant="outline"
                  className="w-full"
                  onClick={() => setShowCancelConfirm(true)}
                  data-testid="button-cancel-subscription"
                >
                  Cancel Subscription
                </Button>
              ) : (
                <Card className="border-destructive">
                  <CardContent className="p-4 space-y-4">
                    <div className="flex items-start gap-3">
                      <AlertTriangle className="h-5 w-5 text-destructive mt-0.5" />
                      <div>
                        <p className="font-medium">Are you sure?</p>
                        <p className="text-sm text-muted-foreground">
                          Your access will continue until the end of your current billing period.
                        </p>
                      </div>
                    </div>
                    <div className="flex gap-2">
                      <Button
                        variant="destructive"
                        onClick={() => cancelMutation.mutate()}
                        disabled={cancelMutation.isPending}
                        data-testid="button-confirm-cancel"
                      >
                        {cancelMutation.isPending ? "Canceling..." : "Confirm Cancel"}
                      </Button>
                      <Button variant="outline" onClick={() => setShowCancelConfirm(false)}>
                        Keep Subscription
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              )}

              {!showRefundConfirm ? (
                <Button
                  variant="ghost"
                  className="w-full text-muted-foreground"
                  onClick={() => setShowRefundConfirm(true)}
                  data-testid="button-request-refund"
                >
                  Request Refund (within 72 hours)
                </Button>
              ) : (
                <Card className="border-amber-500">
                  <CardContent className="p-4 space-y-4">
                    <div className="flex items-start gap-3">
                      <Shield className="h-5 w-5 text-amber-500 mt-0.5" />
                      <div>
                        <p className="font-medium">Request Refund</p>
                        <p className="text-sm text-muted-foreground">
                          Refunds are only available within 72 hours of purchase.
                        </p>
                      </div>
                    </div>
                    <div className="flex gap-2">
                      <Button
                        variant="outline"
                        onClick={() => refundMutation.mutate()}
                        disabled={refundMutation.isPending}
                        data-testid="button-confirm-refund"
                      >
                        {refundMutation.isPending ? "Processing..." : "Request Refund"}
                      </Button>
                      <Button variant="ghost" onClick={() => setShowRefundConfirm(false)}>
                        Cancel
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              )}
            </div>
          )}

          {!isPaid && (
            <Link href="/pricing">
              <Button className="w-full" data-testid="button-upgrade">
                Upgrade Plan
              </Button>
            </Link>
          )}
        </CardContent>
      </Card>

      <Card>
        <CardContent className="p-4">
          <Button variant="ghost" className="w-full text-destructive" onClick={handleLogout} data-testid="button-logout">
            <LogOut className="h-4 w-4 mr-2" />
            Logout
          </Button>
        </CardContent>
      </Card>
    </div>
  );
}
