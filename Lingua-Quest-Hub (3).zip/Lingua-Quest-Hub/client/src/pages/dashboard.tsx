import { useQuery } from "@tanstack/react-query";
import { useAuth } from "@/lib/auth";
import { Link } from "wouter";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { BookOpen, Flame, Trophy, Star, ArrowRight, Target, Calendar } from "lucide-react";
import type { Lesson, Quest } from "@shared/schema";

export default function DashboardPage() {
  const { user } = useAuth();

  const { data: lessons, isLoading: lessonsLoading } = useQuery<Lesson[]>({
    queryKey: ["/api/lessons"],
  });

  const { data: quests, isLoading: questsLoading } = useQuery<(Quest & { progress?: number; completed?: boolean })[]>({
    queryKey: ["/api/quests"],
  });

  const xpProgress = user ? Math.min((user.xp % 1000) / 10, 100) : 0;
  const level = user ? Math.floor(user.xp / 1000) + 1 : 1;

  return (
    <div className="p-6 max-w-7xl mx-auto space-y-8">
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold" data-testid="text-welcome">
            Welcome back, {user?.displayName || user?.username?.split("@")[0] || "Learner"}!
          </h1>
          <p className="text-muted-foreground">Keep up your learning streak</p>
        </div>
        <div className="flex items-center gap-4">
          <Badge variant="secondary" className="text-lg py-2 px-4" data-testid="badge-plan">
            {user?.plan || "FreePack"}
          </Badge>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card data-testid="card-xp">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2 gap-2">
            <CardTitle className="text-sm font-medium">Total XP</CardTitle>
            <Star className="h-5 w-5 text-accent" />
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold">{user?.xp || 0}</div>
            <div className="mt-2">
              <div className="flex justify-between text-sm text-muted-foreground mb-1">
                <span>Level {level}</span>
                <span>{xpProgress}%</span>
              </div>
              <Progress value={xpProgress} className="h-2" />
            </div>
          </CardContent>
        </Card>

        <Card data-testid="card-streak">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2 gap-2">
            <CardTitle className="text-sm font-medium">Current Streak</CardTitle>
            <Flame className="h-5 w-5 text-orange-500" />
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold">{user?.streak || 0} days</div>
            <p className="text-sm text-muted-foreground mt-2">Practice daily to keep it going!</p>
          </CardContent>
        </Card>

        <Card data-testid="card-lessons-completed">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2 gap-2">
            <CardTitle className="text-sm font-medium">Lessons Available</CardTitle>
            <BookOpen className="h-5 w-5 text-primary" />
          </CardHeader>
          <CardContent>
            {lessonsLoading ? (
              <Skeleton className="h-8 w-16" />
            ) : (
              <div className="text-3xl font-bold">{lessons?.length || 0}</div>
            )}
            <p className="text-sm text-muted-foreground mt-2">Ready to learn</p>
          </CardContent>
        </Card>
      </div>

      <Card className="bg-gradient-to-r from-primary/10 to-primary/5 border-primary/20" data-testid="card-daily-quiz">
        <CardContent className="flex items-center justify-between p-6">
          <div className="flex items-center gap-4">
            <div className="h-12 w-12 bg-primary/20 rounded-full flex items-center justify-center">
              <Calendar className="h-6 w-6 text-primary" />
            </div>
            <div>
              <h3 className="text-lg font-bold">Daily Quiz Challenge</h3>
              <p className="text-muted-foreground">
                Test your skills with today's quiz tailored to your level
              </p>
            </div>
          </div>
          <Link href="/daily-quiz">
            <Button data-testid="button-start-daily-quiz">
              Start Quiz
              <ArrowRight className="h-4 w-4 ml-2" />
            </Button>
          </Link>
        </CardContent>
      </Card>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card data-testid="card-next-lesson">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <BookOpen className="h-5 w-5" />
              Continue Learning
            </CardTitle>
            <CardDescription>Pick up where you left off</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            {lessonsLoading ? (
              <>
                <Skeleton className="h-20 w-full" />
                <Skeleton className="h-20 w-full" />
              </>
            ) : (
              lessons?.slice(0, 3).map((lesson) => (
                <Link key={lesson.id} href={`/lessons/${lesson.id}`}>
                  <div className="flex items-center justify-between p-4 border rounded-md hover-elevate cursor-pointer" data-testid={`link-lesson-${lesson.id}`}>
                    <div>
                      <h4 className="font-medium">{lesson.title}</h4>
                      <Badge variant="outline" size="sm">{lesson.difficulty}</Badge>
                    </div>
                    <ArrowRight className="h-5 w-5 text-muted-foreground" />
                  </div>
                </Link>
              ))
            )}
            <Link href="/lessons">
              <Button variant="outline" className="w-full" data-testid="button-view-all-lessons">
                View All Lessons
              </Button>
            </Link>
          </CardContent>
        </Card>

        <Card data-testid="card-quests">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Target className="h-5 w-5" />
              Daily Quests
            </CardTitle>
            <CardDescription>Complete quests to earn XP</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            {questsLoading ? (
              <>
                <Skeleton className="h-16 w-full" />
                <Skeleton className="h-16 w-full" />
              </>
            ) : (
              quests?.filter(q => q.type === "Daily").slice(0, 3).map((quest) => (
                <div key={quest.id} className="flex items-center justify-between p-4 border rounded-md" data-testid={`quest-${quest.id}`}>
                  <div className="flex-1">
                    <h4 className="font-medium">{quest.description}</h4>
                    <div className="flex items-center gap-2 mt-1">
                      <Progress value={(quest.progress || 0) / quest.targetCount * 100} className="h-2 flex-1" />
                      <span className="text-sm text-muted-foreground">
                        {quest.progress || 0}/{quest.targetCount}
                      </span>
                    </div>
                  </div>
                  <Badge variant="secondary" className="ml-4">+{quest.rewardXp} XP</Badge>
                </div>
              ))
            )}
            <Link href="/quests">
              <Button variant="outline" className="w-full" data-testid="button-view-all-quests">
                View All Quests
              </Button>
            </Link>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
