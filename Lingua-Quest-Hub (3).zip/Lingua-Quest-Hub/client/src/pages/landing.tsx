import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { BookOpen, Flame, Trophy, Target, Globe, Zap, ArrowRight, Sparkles, Users, Clock, Mail, Brain } from "lucide-react";

export default function LandingPage() {
  return (
    <div className="min-h-screen bg-gradient-to-b from-background to-muted/20">
      <header className="border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60 sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-6 py-4 flex items-center justify-between gap-4">
          <div className="flex items-center gap-2">
            <div className="h-10 w-10 bg-primary rounded-lg flex items-center justify-center">
              <BookOpen className="h-6 w-6 text-primary-foreground" />
            </div>
            <span className="text-2xl font-bold bg-gradient-to-r from-primary to-primary/60 bg-clip-text text-transparent">
              LinguaQuest
            </span>
          </div>
          <div className="flex items-center gap-2 md:gap-4">
            <Link href="/pricing">
              <Button variant="ghost" data-testid="button-nav-pricing">Pricing</Button>
            </Link>
            <Link href="/auth">
              <Button data-testid="button-nav-login">Get Started</Button>
            </Link>
          </div>
        </div>
      </header>

      <section className="py-16 md:py-24 px-6 relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-primary/5 via-transparent to-accent/5" />
        <div className="absolute top-20 left-10 w-72 h-72 bg-primary/10 rounded-full blur-3xl" />
        <div className="absolute bottom-20 right-10 w-96 h-96 bg-accent/10 rounded-full blur-3xl" />
        
        <div className="max-w-5xl mx-auto text-center space-y-8 relative">
          <Badge variant="secondary" className="text-sm py-1.5 px-4">
            <Sparkles className="h-3.5 w-3.5 mr-1.5" />
            AI-Powered Language Learning
          </Badge>
          <h1 className="text-4xl sm:text-5xl md:text-6xl lg:text-7xl font-bold tracking-tight leading-tight">
            Master English Through
            <span className="block bg-gradient-to-r from-primary via-primary/80 to-accent bg-clip-text text-transparent">
              Gamified Learning
            </span>
          </h1>
          <p className="text-lg md:text-xl text-muted-foreground max-w-2xl mx-auto leading-relaxed">
            Interactive lessons, AI-powered tutorials, daily quests, and achievement tracking 
            make learning English engaging and effective. Start your journey today.
          </p>
          <div className="flex flex-col sm:flex-row items-center justify-center gap-4 pt-4">
            <Link href="/auth">
              <Button size="lg" className="w-full sm:w-auto text-lg px-8 py-6" data-testid="button-hero-start">
                Start Learning Free
                <ArrowRight className="h-5 w-5 ml-2" />
              </Button>
            </Link>
            <Link href="/pricing">
              <Button size="lg" variant="outline" className="w-full sm:w-auto text-lg px-8 py-6" data-testid="button-hero-plans">
                View Plans
              </Button>
            </Link>
          </div>
          
          <div className="flex flex-wrap items-center justify-center gap-6 md:gap-8 pt-8 text-sm text-muted-foreground">
            <div className="flex items-center gap-2">
              <Users className="h-4 w-4 text-primary" />
              <span>10,000+ Learners</span>
            </div>
            <div className="flex items-center gap-2">
              <Trophy className="h-4 w-4 text-accent" />
              <span>500+ Lessons</span>
            </div>
            <div className="flex items-center gap-2">
              <Clock className="h-4 w-4 text-orange-500" />
              <span>Learn in 15 min/day</span>
            </div>
          </div>
        </div>
      </section>

      <section className="py-16 md:py-20 px-6">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">Why Choose LinguaQuest?</h2>
            <p className="text-muted-foreground text-lg max-w-2xl mx-auto">
              Our unique approach combines proven learning methods with gamification and AI
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 md:gap-8">
            <Card className="relative overflow-hidden group hover-elevate">
              <div className="absolute top-0 right-0 w-32 h-32 bg-primary/5 rounded-full -translate-y-1/2 translate-x-1/2" />
              <CardContent className="pt-8 pb-6 space-y-4 relative">
                <div className="w-14 h-14 bg-primary/10 rounded-xl flex items-center justify-center">
                  <BookOpen className="h-7 w-7 text-primary" />
                </div>
                <h3 className="text-xl font-semibold">Interactive Lessons</h3>
                <p className="text-muted-foreground leading-relaxed">
                  Engaging content with quizzes designed for all skill levels from beginner to master
                </p>
              </CardContent>
            </Card>

            <Card className="relative overflow-hidden group hover-elevate">
              <div className="absolute top-0 right-0 w-32 h-32 bg-accent/5 rounded-full -translate-y-1/2 translate-x-1/2" />
              <CardContent className="pt-8 pb-6 space-y-4 relative">
                <div className="w-14 h-14 bg-accent/10 rounded-xl flex items-center justify-center">
                  <Brain className="h-7 w-7 text-accent" />
                </div>
                <h3 className="text-xl font-semibold">AI Tutorials</h3>
                <p className="text-muted-foreground leading-relaxed">
                  Get personalized explanations and practice with our AI-powered learning assistant
                </p>
              </CardContent>
            </Card>

            <Card className="relative overflow-hidden group hover-elevate">
              <div className="absolute top-0 right-0 w-32 h-32 bg-orange-500/5 rounded-full -translate-y-1/2 translate-x-1/2" />
              <CardContent className="pt-8 pb-6 space-y-4 relative">
                <div className="w-14 h-14 bg-orange-100 dark:bg-orange-900/30 rounded-xl flex items-center justify-center">
                  <Flame className="h-7 w-7 text-orange-500" />
                </div>
                <h3 className="text-xl font-semibold">Streak Tracking</h3>
                <p className="text-muted-foreground leading-relaxed">
                  Build habits with daily practice and streak rewards to stay motivated
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      <section className="py-16 md:py-20 px-6 bg-muted/30">
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">Everything You Need to Succeed</h2>
            <p className="text-muted-foreground text-lg">Features designed to accelerate your learning</p>
          </div>
          
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 md:gap-6">
            <Card className="p-5 hover-elevate">
              <div className="flex items-start gap-4">
                <div className="w-10 h-10 bg-primary/10 rounded-lg flex items-center justify-center flex-shrink-0">
                  <Target className="h-5 w-5 text-primary" />
                </div>
                <div>
                  <h3 className="font-semibold mb-1">Daily Quests</h3>
                  <p className="text-sm text-muted-foreground">Complete challenges to earn XP and unlock achievements</p>
                </div>
              </div>
            </Card>
            
            <Card className="p-5 hover-elevate">
              <div className="flex items-start gap-4">
                <div className="w-10 h-10 bg-accent/10 rounded-lg flex items-center justify-center flex-shrink-0">
                  <Trophy className="h-5 w-5 text-accent" />
                </div>
                <div>
                  <h3 className="font-semibold mb-1">Certificates</h3>
                  <p className="text-sm text-muted-foreground">Earn certificates to showcase your progress</p>
                </div>
              </div>
            </Card>
            
            <Card className="p-5 hover-elevate">
              <div className="flex items-start gap-4">
                <div className="w-10 h-10 bg-green-100 dark:bg-green-900/30 rounded-lg flex items-center justify-center flex-shrink-0">
                  <Globe className="h-5 w-5 text-green-600" />
                </div>
                <div>
                  <h3 className="font-semibold mb-1">Multi-Language UI</h3>
                  <p className="text-sm text-muted-foreground">Interface in English, Spanish, French, and Hindi</p>
                </div>
              </div>
            </Card>
            
            <Card className="p-5 hover-elevate">
              <div className="flex items-start gap-4">
                <div className="w-10 h-10 bg-purple-100 dark:bg-purple-900/30 rounded-lg flex items-center justify-center flex-shrink-0">
                  <Zap className="h-5 w-5 text-purple-600" />
                </div>
                <div>
                  <h3 className="font-semibold mb-1">Daily Quizzes</h3>
                  <p className="text-sm text-muted-foreground">Test your skills with rotating quizzes matched to your level</p>
                </div>
              </div>
            </Card>
          </div>
        </div>
      </section>

      <section className="py-16 md:py-20 px-6">
        <div className="max-w-4xl mx-auto">
          <Card className="overflow-hidden border-primary/20 bg-gradient-to-br from-primary/5 to-accent/5">
            <CardContent className="p-8 md:p-12 text-center space-y-6">
              <div className="w-16 h-16 bg-primary/10 rounded-2xl flex items-center justify-center mx-auto">
                <Sparkles className="h-8 w-8 text-primary" />
              </div>
              <h2 className="text-3xl md:text-4xl font-bold">Ready to Start Your Journey?</h2>
              <p className="text-lg text-muted-foreground max-w-xl mx-auto">
                Join thousands of learners improving their English every day with our gamified approach
              </p>
              <Link href="/auth">
                <Button size="lg" className="text-lg px-8 py-6" data-testid="button-cta-start">
                  Create Free Account
                  <ArrowRight className="h-5 w-5 ml-2" />
                </Button>
              </Link>
            </CardContent>
          </Card>
        </div>
      </section>

      <footer className="border-t py-10 px-6 bg-muted/20">
        <div className="max-w-7xl mx-auto">
          <div className="flex flex-col md:flex-row items-center justify-between gap-6">
            <div className="flex items-center gap-2">
              <div className="h-8 w-8 bg-primary rounded-lg flex items-center justify-center">
                <BookOpen className="h-4 w-4 text-primary-foreground" />
              </div>
              <span className="font-semibold text-lg">LinguaQuest</span>
            </div>
            
            <div className="flex items-center gap-6 text-sm text-muted-foreground">
              <a href="#" className="hover:text-foreground transition-colors">Terms</a>
              <a href="#" className="hover:text-foreground transition-colors">Privacy</a>
              <a 
                href="mailto:contact@linguaquest.com" 
                className="flex items-center gap-1.5 hover:text-foreground transition-colors"
                data-testid="link-contact-email"
              >
                <Mail className="h-4 w-4" />
                Contact Us
              </a>
            </div>
            
            <p className="text-sm text-muted-foreground">
              &copy; 2026 LinguaQuest. All rights reserved.
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
}
