import { useQuery } from "@tanstack/react-query";
import { Link } from "wouter";
import { useAuth } from "@/lib/auth";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { BookOpen, ArrowRight, CheckCircle, Eye } from "lucide-react";
import type { Lesson, LessonProgress } from "@shared/schema";

const skillToDifficulty: Record<string, string> = {
  beginner: "beginner",
  intermediate: "intermediate",
  expert: "advanced",
  master: "advanced",
};

export default function LessonsPage() {
  const { user } = useAuth();
  const { data: lessons, isLoading } = useQuery<Lesson[]>({
    queryKey: ["/api/lessons"],
  });

  const { data: progress } = useQuery<LessonProgress[]>({
    queryKey: ["/api/progress"],
  });

  const completedLessonIds = new Set(progress?.filter(p => p.completed).map(p => p.lessonId) || []);
  
  const userSkillLevel = user?.skillLevel || "beginner";
  const defaultTab = skillToDifficulty[userSkillLevel] || "beginner";

  const allLessons = lessons || [];
  const completedLessons = allLessons.filter(l => completedLessonIds.has(l.id));
  const incompleteLessons = allLessons.filter(l => !completedLessonIds.has(l.id));

  const beginnerLessons = incompleteLessons.filter((l) => l.difficulty === "Beginner");
  const intermediateLessons = incompleteLessons.filter((l) => l.difficulty === "Intermediate");
  const advancedLessons = incompleteLessons.filter((l) => l.difficulty === "Advanced");

  const LessonCard = ({ lesson, isCompleted = false }: { lesson: Lesson; isCompleted?: boolean }) => (
    <Link href={`/lessons/${lesson.id}${isCompleted ? "?review=true" : ""}`}>
      <Card className="hover-elevate cursor-pointer" data-testid={`card-lesson-${lesson.id}`}>
        <CardHeader className="pb-2 gap-2">
          <div className="flex items-start justify-between gap-2">
            <CardTitle className="text-lg">{lesson.title}</CardTitle>
            <div className="flex gap-1">
              {isCompleted && <Badge variant="secondary"><CheckCircle className="h-3 w-3 mr-1" />Done</Badge>}
              <Badge variant="outline">{lesson.difficulty}</Badge>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <p className="text-sm text-muted-foreground line-clamp-2">
            {lesson.content.replace(/[#*\-]/g, "").substring(0, 100)}...
          </p>
          <Button variant="ghost" size="sm" className="mt-4 p-0">
            {isCompleted ? (
              <>Review Answers <Eye className="h-4 w-4 ml-2" /></>
            ) : (
              <>Start Lesson <ArrowRight className="h-4 w-4 ml-2" /></>
            )}
          </Button>
        </CardContent>
      </Card>
    </Link>
  );

  return (
    <div className="p-6 max-w-7xl mx-auto space-y-8">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold flex items-center gap-2">
            <BookOpen className="h-8 w-8 text-primary" />
            Lessons
          </h1>
          <p className="text-muted-foreground mt-1">Master English step by step</p>
        </div>
      </div>

      <Tabs defaultValue={defaultTab} className="w-full">
        <TabsList className="grid w-full grid-cols-4 max-w-lg">
          <TabsTrigger value="beginner" data-testid="tab-beginner">
            Beginner ({beginnerLessons.length})
          </TabsTrigger>
          <TabsTrigger value="intermediate" data-testid="tab-intermediate">
            Intermediate ({intermediateLessons.length})
          </TabsTrigger>
          <TabsTrigger value="advanced" data-testid="tab-advanced">
            Advanced ({advancedLessons.length})
          </TabsTrigger>
          <TabsTrigger value="completed" data-testid="tab-completed">
            Completed ({completedLessons.length})
          </TabsTrigger>
        </TabsList>

        <TabsContent value="beginner" className="mt-6">
          {isLoading ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {[1, 2, 3].map((i) => (
                <Skeleton key={i} className="h-40" />
              ))}
            </div>
          ) : beginnerLessons.length === 0 ? (
            <Card className="p-8 text-center">
              <p className="text-muted-foreground">No beginner lessons available yet.</p>
            </Card>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {beginnerLessons.map((lesson) => (
                <LessonCard key={lesson.id} lesson={lesson} />
              ))}
            </div>
          )}
        </TabsContent>

        <TabsContent value="intermediate" className="mt-6">
          {isLoading ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {[1, 2, 3].map((i) => (
                <Skeleton key={i} className="h-40" />
              ))}
            </div>
          ) : intermediateLessons.length === 0 ? (
            <Card className="p-8 text-center">
              <p className="text-muted-foreground">No intermediate lessons available yet.</p>
            </Card>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {intermediateLessons.map((lesson) => (
                <LessonCard key={lesson.id} lesson={lesson} />
              ))}
            </div>
          )}
        </TabsContent>

        <TabsContent value="advanced" className="mt-6">
          {isLoading ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {[1, 2, 3].map((i) => (
                <Skeleton key={i} className="h-40" />
              ))}
            </div>
          ) : advancedLessons.length === 0 ? (
            <Card className="p-8 text-center">
              <p className="text-muted-foreground">No advanced lessons available yet.</p>
            </Card>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {advancedLessons.map((lesson) => (
                <LessonCard key={lesson.id} lesson={lesson} />
              ))}
            </div>
          )}
        </TabsContent>

        <TabsContent value="completed" className="mt-6">
          {isLoading ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {[1, 2, 3].map((i) => (
                <Skeleton key={i} className="h-40" />
              ))}
            </div>
          ) : completedLessons.length === 0 ? (
            <Card className="p-8 text-center">
              <CheckCircle className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
              <p className="text-muted-foreground">No completed lessons yet. Start learning!</p>
            </Card>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {completedLessons.map((lesson) => (
                <LessonCard key={lesson.id} lesson={lesson} isCompleted />
              ))}
            </div>
          )}
        </TabsContent>
      </Tabs>
    </div>
  );
}
